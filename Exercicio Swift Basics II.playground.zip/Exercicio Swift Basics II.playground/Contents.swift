/*:
 
 # Você foi designado para criar uma estrutura de RPG

 Você é o mestre responsável por um RPG. Como grande criador, você precisa criar os habitantes desse mundo, suas funções e ferramentas para tudo fazer sentido e a experiência ser incrível! No entanto, a tarefa será cheia de desafios, e você deve cumpri-los para finalizar seu mundo.
 
 1) Para suas futuras batalhas, criar armas é essencial. Armas são equipamentos simples: cada uma tem um nome e gera um dano. Experimente!
 
  ##### Use struct
*/
import Foundation

func randomBool() -> Bool {
    return arc4random_uniform(2) == 0
}

struct Arma {
    var nome: String
    var dano: Int
    
    init(nome: String, dano: Int) {
        self.nome = nome
        self.dano = dano
    }
}


/*:
 
 2) O mundo possui elementos essenciais para a sua existência e equilíbrio… Este possui os quatro elementos: água, fogo, terra e trovão. Entretanto, cada um possui fraqueza a algum tipo de elemento. Você deve criar os elementos e suas fraquezas seguindo o guia abaixo:
 
 - Água  < Trovão
 - Fogo < Água
 - Terra < Fogo
 - Trovão < Terra
 
 ##### Use Enum com uma variável computada
 
*/

enum Elemento {
    case agua
    case fogo
    case terra
    case trovao
    
    var fraqueza: Elemento {
        switch self {
        case .agua:
            return(.trovao)
        case .fogo:
            return(.agua)
        case .terra:
            return(.fogo)
        case .trovao:
            return(.terra)
        }
    }
}

Elemento.agua.fraqueza

/*:
3) Tão antigas quanto a criação do mundo, as Runas possuem um Elemento que o regem e uma quantidade de dano, o que as torna únicas. Crie uma estrutura para as Runas no seu mundo.
 ##### Use Struct
*/

struct Runa {
    var elemento: Elemento
    var dano: Int
}


/*:
 4) Um grande mundo como este possui todo tipo de criatura… Humanos, monstros, magos e heróis… Mas o que todos eles têm em comum? Todo Personagem possui um nome, uma quantidade de vida e de força.
 Além do mais, todos são capazes de atacar outros personagens, e embora façam isso de diferentes maneiras, o ataque padrão de todos é retirar pontos de vida de outro personagem com a sua força. Estruture um tipo de personagem default.
 
 ##### Use Protocolos
 */

protocol Personagem {
    var nome: String { get set }
    var pontosDeVida: Int { get set }
    var forca: Int { get set }
    
    func atacar (alvo: inout Personagem) -> ()
}

/*:
5) Agora que sabemos o que todo personagem faz, podemos criar os nossos! Para começar, vamos criar um Cavaleiro. O Cavaleiro é um personagem que possui uma arma para atacar, e pode servir de  base para outros. Por padrão, todo Cavaleiro inicia com 100 de vida e 5 de força. Quando ataca, retira da vida do outro personagem a sua força somada ao dano de sua arma.
 
 ##### Use Classe
*/
class Cavaleiro: Personagem {
    var nome: String = ""
    
    var pontosDeVida: Int = 100
    
    var forca: Int = 5
    
    var arma: Arma = Arma(nome: "Espada", dano: 5)
    
    init(nome: String, pontosDeVida: Int, forca: Int, arma: Arma) {
        self.nome = nome
        self.pontosDeVida = pontosDeVida
        self.forca = forca
        self.arma = arma
    }
    
    func atacar(alvo: inout Personagem) -> () {
        alvo.pontosDeVida -= (self.forca + self.arma.dano)
    }
    
    
    
    
}



/*:
6) Neste mundo desafiador, Monstros poderão sempre estar à espreita. Um Monstro é um personagem que possui um Elemento da natureza associado a ele. Seu ataque gera dano através da própria força, apenas, pois não possui armas.
 
 ##### Use Classe

*/
class Monstro: Personagem {
    var nome: String
    
    var pontosDeVida: Int
    
    var forca: Int
    
    var elemento: Elemento
    
    init(nome: String, pontosDeVida: Int, forca: Int, elemento: Elemento) {
        self.nome = nome
        self.pontosDeVida = pontosDeVida
        self.forca = forca
        self.elemento = elemento
    }
    
    func atacar(alvo: inout Personagem) {
        alvo.pontosDeVida -= (self.forca)
    }
    
}

let monstro = Monstro(nome: "Babidi", pontosDeVida: 33, forca: 15, elemento: Elemento.agua)

/*:
7) Em resposta à evolução dos Monstros, certos Cavaleiros aprenderam a dominar o poder das Runas elementais e ganharam a habilidade de atacar monstros de elementos mais fracos, Um Cavaleiro Rúnico é um cavaleiro que, se tiver uma runa forte contra a de um monstro, pode atacar estes monstros com elementos mais fracos com 2 vezes o dano da runa, mais o dano da sua arma. Se a runa não for mais forte, ele ainda consegue atacar com sua arma e o dano da runa. Se o Cavaleiro Runico não estiver equipado com qualquer Runa ele utiliza o ataque normal do Cavaleiro.
 
 ##### Crie uma subclasse de Cavaleiro e sobrescreva a função ataque.
 
*/

class CavaleiroRunico: Cavaleiro {
    var runa: Runa?
    
    override func atacar(alvo: inout Personagem ) {
        if let alvo = alvo as? Monstro {
            if self.runa == nil || alvo.elemento.fraqueza != self.runa!.elemento {
                alvo.pontosDeVida -= (self.forca + self.arma.dano)
            } else {
                alvo.pontosDeVida -= (2 * (runa!.dano))
            }
        }
    }
}


/*:
8) Agora você precisa criar um sistema simples de batalha. Uma batalha acontece entre dois personagens e uma vez que ela se inicia os personagens atacam em turnos, durando até que a vida de uma dos personagens chegue a zero. Em cada turno há uma chance aleatória do ataque ser bem sucedido ou não. Ao fim da batalha deve ser exibido o nome do vencedor.
 
 ##### Crie um objeto para gerenciar a batalha
 
*/
var lightSaber: Arma = Arma(nome: "Light Saber", dano: 5)

var rey: Personagem = Cavaleiro(nome: "Rey Skywalker", pontosDeVida: 100, forca: 5, arma: lightSaber)

var palpatine: Personagem = Monstro(nome: "Palpatine", pontosDeVida: 100, forca: 4, elemento: Elemento.trovao)


class Batalha {
    var lutador1: Personagem
    var lutador2: Personagem
    var turno: Int = 0
    
    init(lutador1: Personagem, lutador2: Personagem) {
        self.lutador1 = lutador1
        self.lutador2 = lutador2
    }
    
    func iniciarLuta() -> () {
        self.turno = 0
        while true {
            print("Turno \(self.turno):")
            if randomBool() {
                self.lutador1.atacar(alvo: &self.lutador2)
                print("\(self.lutador1.nome) ataca \(self.lutador2.nome) com sucesso!")
            } else {
                print("\(self.lutador1.nome) fracassou neste ataque")
            }
            
            if self.lutador2.pontosDeVida <= 0 {
                print("\(self.lutador2.nome) is dead. \(self.lutador1.nome) é o(a) vencedor(a)!")
                break
            }
            
            if randomBool() {
                self.lutador2.atacar(alvo: &self.lutador1)
                print("\(self.lutador2.nome) ataca \(self.lutador1.nome) com sucesso!")
            } else {
                print("\(self.lutador2.nome) fracassou neste ataque")
            }
            
            if self.lutador1.pontosDeVida <= 0 {
                print("\(self.lutador1.nome) is dead. \(self.lutador2.nome) é o(a) vencedor(a)!")
                break
            }
            turno += 1
        }
    }

}

var batalha: Batalha = Batalha(lutador1: rey, lutador2: palpatine)
batalha.iniciarLuta()


/*:
9) Nesse mundo existe algo tão necessário quanto no nosso mundo que são moedas! Uma Moeda é uma estrutura simples que possui um valor. Como as moedas tem que ser guardadas em algum lugar, você deve criar um Saco de Moedas que é um tipo de Armazenamento especifico para moedas. Um Armazenamento é capaz de guardar uma coleção de um tipo de item e existem Armazenamentos para diferentes tipos. Todo Armazenamento possui uma função de armazenar que consiste em inserir um item na sua coleção de itens.
 
  ##### Use Protocolo com tipo associado e Structs
 */

protocol Armazenamento {
    associatedtype Item
    var moedas: [Item] { get set }
    mutating func append(_ item: Item)
}

struct Moeda {
    var valor: Int
}

struct SacoDeMoedas: Armazenamento {
    typealias Item = Moeda
    var moedas: [Moeda] = []
    var total: Int {
        get {
            moedas.reduce(0) { (acumulador: Int, moeda: Moeda) -> Int in
                return acumulador + moeda.valor
            }
        }
        
    }
    
    mutating func append(_ moeda: Moeda) -> () {
        self.moedas.append(moeda)
    }
}

var moeda = Moeda(valor: 10)
var saco = SacoDeMoedas()
saco.append(moeda)
saco.append(moeda)
saco.append(moeda)
saco.append(moeda)
saco.append(moeda)
print("ok")
print(saco.total)


