/*: Exercícios Swift Basics

# Ajude o Tales!
 
 Tales é um jovem que começou a trabalhar pela primeira vez e com um contrato temporário em uma revendedora de automóveis. Ele precisa da sua ajuda para conseguir realizar todas as suas funções e conseguir manter seu emprego mesmo após o fim do contrato, porém essa tarefa não será fácil já que seu gerente é extremamente exigente e passou uma série de demandas.
 
 1) Magno, o gerente pediu para que Tales estruturasse todos os veículos da loja para ele. Um veículo tem: Marca, Nome, Cor, Preço e Tipo (Carro ou Moto). Segue a lista dos veículos:
 
 - Nissan - March - Branco - 42.000 - Carro
 - Ford - ??? - Preto - 40.000 - Carro
 - Honda - Biz 125 - Azul - 9.120 - Moto
 - Yamaha - XTZ 250 - Azul - 11.990 - Moto
 - Nissan - ??? - Branco - 82.00 - Carro
 - Suzuki - Gran Vitara - Prata - 87.000 - Carro
 - Honda - ??? - Preto - 4.999 - Moto
 - Yamaha - YS 250 - Verde - 10.990 - Moto
 
 ##### Use tuplas, typealias e array
 */





/*:
 2) Agora eu preciso preparar uma lista com todos os veículos do tipo "Moto", urgentemente!
 */





/*:
 3) Não acredito... apareceu um comprador interesado em comprar todos os veículos preto. Então ele pediu uma lista de todos os veículos pretos com o preço ordenado do menor pro maior.
 */





/*:
 4) Magno.... sempre ele. Agora ele quer que eu informe pra eles quais são os veículos que nós ainda não catalogamos o nome.
 ##### Não pode usar nenhuma estrutura condicional (if) e nem de controle (for, while, switch)
 */





/*:
 5) Acho que estamos terminando, ufa! Ele pediu quanto nós ganharíamos caso a loja venda todos os seus veículos.
 */





/*:
 6) Temos muitos clientes estranhos. Preciso montar um orçamento de quanto custaria todos os carros brancos.
 ##### Não pode usar nenhuma estrutura condicional (if) e nem de controle (for, while, switch)
 */






/*:
 7) Tivemos uma mudança tributária, desta forma preciso atualizar o preço de todos os veículos acrescentando 2% de reajuste.
 */






/*:
 8) Caramba, me passaram informações erradas. Preciso fazer o reajuste de 2% apenas nos carros.
 ##### Não pode usar nenhuma estrutura condicional (if) e nem de controle (for, while, switch)
 */







// O Reduce é um método que está contido dentro das Coleções (Array, Dictonary), leia a documentação para ver o seu funcionamento https://developer.apple.com/documentation/swift/array/2298686-reduce , após a leitura crie um array de inteiro que contem números de 1 até 10. Inicialmente, aplique o reduce gerando o somatório destes valores, após isso implemente uma função reduzir que funciona exatamente como o reduce nativo nas coleções. Como conteúdo complementar segue a documentação de closures: https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/Closures.html#//apple_ref/doc/uid/TP40014097-CH11-ID94


