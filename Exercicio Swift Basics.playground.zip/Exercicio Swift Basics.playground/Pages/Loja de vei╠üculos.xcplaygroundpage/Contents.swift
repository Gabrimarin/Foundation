/*: Exercícios Swift Basics

# Ajude o Tales!
 
 Tales é um jovem que começou a trabalhar pela primeira vez e com um contrato temporário em uma revendedora de automóveis. Ele precisa da sua ajuda para conseguir realizar todas as suas funções e conseguir manter seu emprego mesmo após o fim do contrato, porém essa tarefa não será fácil já que seu gerente é extremamente exigente e passou uma série de demandas.
 
 1) Magno, o gerente pediu para que Tales estruturasse todos os veículos da loja para ele. Um veículo tem: Marca, Nome, Cor, Preço e Tipo (Carro ou Moto). Segue a lista dos veículos:
 
 - Nissan - March - Branco - 42.000 - Carro
 - Ford - ??? - Preto - 40.000 - Carro
 - Honda - Biz 125 - Azul - 9.120 - Moto
 - Yamaha - XTZ 250 - Azul - ??? - Moto
 - Nissan - ??? - Branco - 82.00 - Carro
 - Suzuki - Gran Vitara - Prata - ??? - Carro
 - Honda - ??? - Preto - 4.999 - Moto
 - Yamaha - YS 250 - Verde - 10.990 - Moto
 
 ##### Use tuplas, typealias e array
 */
typealias Veiculo = (marca: String?, nome: String?, cor: String?, preco: Double?, tipo: String)
var Nissan1: Veiculo = ("Nissan", "March", "Branco", 42000, "Carro")
var Ford1: Veiculo = (marca: "Ford", nome: nil, cor: "Preto", 40000, "Carro")
var Honda1: Veiculo = ("Honda", "Biz 125", "Azul", 9120, "Moto")
var Yamaha1: Veiculo = ("Yamaha", "XTZ 250", "Azul", nil, "Moto")
var Nissan2: Veiculo = ("Nissan", nil , "Branco", 8200, "Carro")
var Suzuki1: Veiculo = ("Suzuki", "Gran Vitara", "Prata", nil, "Carro")
var Honda2: Veiculo = ("Honda", nil, "Preto", 4999, "Moto")
var Yamaha2: Veiculo = ("Yamaha", "YS 250", "Verde", 10990, "Moto")


var listaVeiculos: [Veiculo] = [Nissan1, Nissan2, Ford1, Suzuki1, Yamaha1, Yamaha2, Honda1, Honda2]
print(listaVeiculos)



/*:
 2) Agora eu preciso preparar uma lista com todos os veículos do tipo "Moto", urgentemente!
 */
let motos = listaVeiculos.filter { veiculo -> Bool in
    return (veiculo.tipo == "Moto")
}
print(motos)




/*:
 3) Não acredito... apareceu um comprador interesado em comprar todos os veículos preto. Então ele pediu uma lista de todos os veículos pretos com o preço ordenado do menor pro maior.
 */

var veiculosPretos = listaVeiculos.filter { veiculo -> Bool in
    return (veiculo.cor == "Preto")
}

veiculosPretos.sort (by: {
    return $0.preco! > $1.preco!
})

print(veiculosPretos)




/*:
 4) Magno.... sempre ele. Agora ele quer que eu informe pra eles quais são os veículos que nós ainda não catalogamos o nome.
 ##### Não pode usar nenhuma estrutura condicional (if) e nem de controle (for, while, switch)
 */
let semNome = listaVeiculos.filter { (veiculo) -> Bool in
    return (veiculo.nome == nil)
}

print(semNome)




/*:
 5) Acho que estamos terminando, ufa! Ele pediu quanto nós ganharíamos caso a loja venda todos os seus veículos.
 */

let ganhoTotal = listaVeiculos.reduce(0) { (resultado: Int, veiculo: Veiculo) -> (Int) in
    return resultado + Int((veiculo.preco ?? 0))
}

print(ganhoTotal)


/*:
 6) Temos muitos clientes estranhos. Preciso montar um orçamento de quanto custaria todos os carros brancos.
 ##### Não pode usar nenhuma estrutura condicional (if) e nem de controle (for, while, switch)
 */
var carrosBrancos = listaVeiculos.filter { veiculo -> Bool in
    return (veiculo.tipo == "Carro" && veiculo.cor == "Branco")
}

var valorCarrosBrancos = carrosBrancos.reduce(0) { (acumulador:Double, veiculo: Veiculo) -> Double in
    return acumulador + (veiculo.preco ?? 0)
}
print(valorCarrosBrancos)





/*:
 7) Tivemos uma mudança tributária, desta forma preciso atualizar o preço de todos os veículos acrescentando 2% de reajuste.
 */


for i in 0..<listaVeiculos.count {
    if listaVeiculos[i].preco != nil {
        listaVeiculos[i].preco! *= 1.02
    }
}
//print(listaVeiculos)

var aux = listaVeiculos.map { (veiculo: Veiculo) -> Veiculo in
    var veic: Veiculo = veiculo
    if veic.preco != nil { veic.preco! *= 1.02 }
    return veic
}
listaVeiculos = aux
print("alterados")
print(listaVeiculos)


/*:
 8) Caramba, me passaram informações erradas. Preciso fazer o reajuste de 2% apenas nos carros.
 ##### Não pode usar nenhuma estrutura condicional (if) e nem de controle (for, while, switch)
 */
//for i in 0..<listaVeiculos.count {
//    if listaVeiculos[i].preco != nil && listaVeiculos[i].tipo == "Moto" {
//        listaVeiculos[i].preco! /= 1.02
//    }
//}

var aux2 = listaVeiculos.map { (veiculo: Veiculo) -> Veiculo in
    var veic: Veiculo = veiculo
    if veic.preco != nil && veic.tipo == "Moto" { veic.preco! *= 1.02 }
    return veic
}
listaVeiculos = aux2
print("alterados")
print(listaVeiculos)




/*: 
## Muito obrigado, com a sua ajuda eu consegui manter meu emprego!
 
 */



//: [Próximo](@next)










