//: [Previous](@previous)


let numbers = [1,2,3,4,5,6,7,8,9,10]

/*: 
 O Filter é um método que está contido dentro das Coleções (Array, Dictonary), leia a [documentação](https://developer.apple.com/documentation/swift/lazycollection/2906574-filter) para ver o seu funcionamento.Implemente uma função filtar que funciona exatamente como o reduce nativo nas coleções. Como conteúdo complementar segue a [documentação](https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/Closures.html#//apple_ref/doc/uid/TP40014097-CH11-ID94) de closures.
 */
func filtro<T>( _ lista: [T], condicao: (T) -> Bool ) -> [T]{
    var listaAux = [T]()
    for elemento in lista {
        if condicao(elemento) {
            listaAux.append(elemento)
        }
    }
    return listaAux
}

print(filtro(numbers) {(valor) -> Bool in
    return  valor % 2 == 0})


/*:
 O Map é um método que está contido dentro das Coleções (Array, Dictonary), leia a [documentação](https://developer.apple.com/documentation/swift/array/2908681-map) para ver o seu funcionamento. Implemente uma função mapear que funciona exatamente como o Map nativo nas coleções.
 */
let integers = [1,2,3,4,5,6,7,8,9,10]

let arrayDobrado = integers.map { (valor) -> Int in
    return valor * 2
}

func mapear<T> ( _ lista: [T], acao: (T) -> (T) ) -> [T] {
    var listaAux = [T]()
    for elemento in lista {
        listaAux.append(acao(elemento))
    }
    return listaAux
}

print(mapear(numbers) {(valor) -> Int in
return  valor * 2})



/*:
 O Reduce é um método que está contido dentro das Coleções (Array, Dictonary), leia a [documentação](https://developer.apple.com/documentation/swift/array/2298686-reduce) Implemente uma função reduzir que funciona exatamente como o reduce nativo nas coleções.
 */
let somatorio = integers.reduce(0) { (valorPrevio, valor) -> Int in
    return valorPrevio + valor
}

print(somatorio)



