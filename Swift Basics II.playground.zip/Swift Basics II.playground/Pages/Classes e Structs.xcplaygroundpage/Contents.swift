/*:
 [Enumerations](@previous)
 
 # Classes e Structs
 
 Classes e Structs são estruturas flexíveis que constituem o código do nosso programa, você pode definir propriedades e métodos que adicionam funcionalidades as suas classes e estruturas.
 
 No **Swift** não há necessidade de criar arquivos de interface e implementação separados, classes e structs são definidas em um único arquivo.
 
 ### Coisas em comum:
 
 * Definem propriedades
 * Definem métodos
 * Definem construtores
 * Podem ser extendidos para expandir funcionalidades
 * Podem assinar protocolos
 
 ### Diferencial de Classes:
 * Herança
 * Deinitializers permitem que instancias liberem recursos
 * Type Casting permite que você avalie e interprete o tipo de uma instância de classe em tempo de execução
 * Mais de uma referência para a instância de uma classe
 
 > Structs são **Value Types** e são passados por cópia, enquanto classes são ** Reference Types ** e são passado por referência, o que significa que structs não usam o contador de referência.
 > Exemplo:
 */




/*:
 > Structs possuem inicializadores auto-gerados com todas as propriedades
 */


/*:
 ### Refêrencia vs Valor
 
 Em **Swift** Classes e Closures são Reference Types, todo o resto é Value Type
 > Exemplo:
 */


/*:
 > **Quando usar structs:**
 * Quando queremos encapsular dados relativamente simples
 * Quando Propriedades do modelo também são **Value Types**
 * Quando o modelo não precisa herdar nenhuma propriedade ou comportamentos de modelos existentes ( Pode ser alcançado através de protocolos também )
 * Quando os dados encapsulados devem ser copiados e não referenciados
 > Exemplo:
 */



/*:
 ## Propriedades
 ### Stored Properties
 Uma constante ou variável que é parte de um instância de classe ou struct
 > Exemplo:
 */



/*:
 ### Lazy Stored Properties
 
 * É uma propriedade a qual seu valor só é calculado quando é usada a primeira vez
 * Usada onde valores iniciais dependem de fatores externos
 * Usada quando existe uma inicialização custosa ou complexa
 
 A palavra chave é `lazy`
 > Exemplo:
 */
struct Point {
    var x: Double = 0
    var y: Double = 0
    var z: Double = 0
    lazy var pointOnboard : Double = {
        return 3.1415*2
    }()
}



/*:
 ### Computed Stored Properties
 
 * Não armazenam um valor propriamente dito
 * Provêm um getter e um setter que é opcional
 > Exemplo:
 */



/*:
 ### Read Only Computed Stored Properties
 
 * Computada apenas com o get
 > Exemplo:
 */
struct Size {
    var width = 0.0, height = 0.0
}

struct Rect {
    var orig = Point()
    var size = Size()
    
    var center: Point {
        get {
            let centerX = orig.x + size.width/2
            let centerY = orig.y + size.height/2
            return Point(x: centerX, y: centerY)
        }
        
        set {
            orig.x = newValue.x - (size.width / 2)
        }
    }
}


/*:
 ### Property Observers
 
 * Respondem a mudanças no valor de uma propriedade
 * São chamados sempre que o valor é atribuído, mesmo quando não difere do atual
 * Pode-se adicionar observers para propriedades herdadas
 * Podemos usar os observers willSet e didSet
 
 
 > Exemplo:
 */

var gretting = "gabriel" {
    didSet {
        print("Welcome \(gretting)")
    }
    willSet {
        print("Bye \(gretting)")
    }
}

gretting = "Lennon"




/*:
 ## Métodos
 
 * Funções associadas a classes, structs ou enums
 * Instância vs Tipo
 
 > Exemplo:
 */
struct CalculatorS {
    static func sum (num1: Double, num2: Double) -> Double {
        return num1 + num2
    }
}
// static func ---- n precisa instanciar o objeto (abstrato)

class CalculatorC {
    func sum (num1: Double, num2: Double) -> Double {
        return num1 + num2
    }
}
 
enum CalculatorE {
    case sum
    case sub
    case mult
    case div
    
    func operation (num1: Double, num2: Double) -> Double {
        switch self {
        case .sum:
            return num1 + num2
        case .sub:
            return num1 - num2
        case .mult:
            return num1 * num2
        case .div:
            return num1/num2
            
        }
    }
}

print(CalculatorE.sum.operation(num1: 2.3, num2: 3.4))

/*:
 > Modifique a estrutura para que ela mantenha o estado da operação anterior e caso o segundo número não seja passado ao realizar a operação, utilize o valor já existente na mémoria.
 */
struct Calc {
    var result = 0
    
    mutating func sum(num1: Int, num2: Int? = nil) -> Int {
        guard let num2 = num2 else {
            result = num1 + result
            return result
        }
        result = num1 + num2
        return result
    }
}




/*:
 
 
 ### Inicialização
 
 * a palavra chave é `init`
 * pode-se customizar a inicialização com passagem de parâmetros
 
 > Exemplo:
 */
import Foundation

class Person {
    var name: String
    var age: Int
    var birth: Date
    
    init(name: String, age: Int, birth: Date) {
        self.name = name
        self.age = age
        self.birth = birth
    }
}


/*:
 > Se seu modelo possue propriedades que podem ser nulas, declaramos como optionals
 */
class SurveyQuestion {
    var text: String
    var response: String?
    
    init(text: String) {
        self.text = text
    }
}


/*:
 ## Herança
 
 * Diferencia classes de outros tipos
 * Maneira de herdar métodos ou propriedades e outras características de outras classe
 
 > Exemplo:
 */
class Part {
    var manufacturer = ""
    var description = ""
    var number = 0
}

class Tire: Part {
    var speed = 0.0
    var rating = 3.5
}

Tire()
/*:
 ### Override
 
 * Você pode sobreescrever, métodos e propriedades
 * Maneira de herdar métodos ou propriedades e outras características de outras classe
 
 > Exemplo:
 */
class Vehicle {
    var description: String {
        get {return "Traveling at"}
    }
    func makeNoise() {
        print("BrruuumA")
    }
}

class Train: Vehicle {
    override func makeNoise() {
        print("piuiiiii ch ch ch ch")
    }
}

class Car: Vehicle {
    var gear = 1
    var speed = 25.0
    override var description: String {
        get {
            return super.description + "at \(speed)Km/h in gear \(gear)"
        }
        set {
            print("meh")
        }
    }
}




/*:
 > Você pode tornar uma propriedade apenas de leitura para Read and Write através de override, porém não pode transformar uma propriedade Read and Write para apenas leitura
 */

/*:
 > Para prevenir que propriedades ou métodos sejam subscritos ou classes sejam herdadas, adicione o `final`
 */


/*:
 ### Type Casting
 
 * `is` checa o tipo de um valor
 * `as` converte um valor para um tipo diferente
 
 > Exemplo:
 */
let vehicles: [Vehicle] = [Car(), Train()]



//: [Protocols](@next)
