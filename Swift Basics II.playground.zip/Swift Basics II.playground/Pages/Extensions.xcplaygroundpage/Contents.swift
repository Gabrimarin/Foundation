
import Foundation
/*:
 [Protocols](@previous)
 
 # Extensões
 * Adicionam novas funcionalidades a tipos existentes.
 * Permite extender tipos que não temos acesso ao código fonte.
 
 ### Podemos com extensões:
 
 1. Adicionar propriedades computadas de instância e tipo.
 2. Definir métodos de instância e de tipo.
 3. Prover novos iniciadores.
 4. Definir novos tipos aninhados.
 5. Fazer com que um tipo existente entre em conformidade com protocolos.
 6. Definir implementações padrão para métodos definidos em protocolos.
 */
let a: String = "a"
extension String {
    var asInt: Int? {
        get{
            return Int(self)
        }
    }
}

let int: Int? = a.asInt

/*:
 ### Sintaxe
 */




/*:
 ### Propriedades Computadas
 */



/*:
 ### Inicializadores
 */



/*:
 ### Métodos
 */



/*:
 > Métodos de Mutação
 */




