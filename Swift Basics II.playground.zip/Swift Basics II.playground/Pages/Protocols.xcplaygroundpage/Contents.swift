import Foundation
/*:
 [Classes e Structs](@previous)
 
 # Protocolos
 
 Definem um conjunto de métodos, propriedades e inicializadores
 
 * Podem ser adotados por classes, structs e enums
 * Quando tipo adota um protocolo é dito que está em conformidade com o protocolo
 
 Exemplo:
 */
protocol OneProtocol {
    var a: String { get set }
    var b: String { get set }
    func foo() -> Bool
}

extension OneProtocol {
    func foo() -> Bool {
        return true
    }
}

protocol SecondProtocol {
    func bla() -> Bool
}

protocol MasterProtocol: OneProtocol, SecondProtocol {
    
}

struct Bar: MasterProtocol {
    var a: String
    
    var b: String
    
    func bla() -> Bool {
        return true
    }
    
    
}

/*:
 ### Propriedades
 
 * Um protocolo pode requerer que os tipos que o adotam provenham propriedades de instância e de tipo.
 * Não se especifica se uma propriedade é armazenada ou computada
 * Apenas é especificado nome e tipo
 * Também especifica-se os acessos a propriedade (`{get}`, `{get set}`
 
 */
protocol Mammal {
    var numberOfLegs: Int { get }
    var monthsPregnant: Int { get set }
}

class Human: Mammal {
    var monthsPregnant: Int
    
    
    var numberOfLegs: Int {
        get {
            return 2
        }
    }
    
    init() {
        self.monthsPregnant = 9
    }
    
}







/*:
 ### Métodos
 * Protocolos podem especificar métodos de instância e de tipo
 * Não é permitido definir valores padrão para parâmetros de métodos especificados em protocolos.
 
 > Protocolos podem especificar um inicializador para classes.
 > Sempre devemos marcar a implementação do iniciador com required.
 */
protocol LivingThing {
    var birth: Date { get set }
    var death: Date?{ get set }
    var age: Int { get }
    
    init(birth: Date, death: Date?)
    func die()
    static func calculateAge(birth: Date, death: Date?) -> Int
}

class Sapiens: LivingThing {
    var birth: Date
    
    var death: Date?
    
    var age: Int {
        get {
            return Sapiens.calculateAge(birth: birth, death: death)
        }
    }
    
    required init(birth: Date, death: Date?) {
        self.birth = birth
        self.death = death
    }
    
    func die() {
        death = Date()
    }
    
    static func calculateAge(birth: Date, death: Date?) -> Int {
        let ageInterval = death != nil ? death! : Date()
        let calendar = Calendar.current
        return calendar.dateComponents([.year], from: birth, to: ageInterval).year ?? 0
    }
    
    
}










/*:
 ### Associated Types
 * São placeholders para tipos usados nas definições do protocolo;
 * O tipo só será definido quando o protocolo for adotado;
 * São definidos usando a palavra chave associatedtype;
 > 
 */
protocol Container {
    associatedtype Item
    
    var items: [Item] {get}
    func append(_ item: Item)
}

class Box: Container {
    
    typealias Item = Sapiens
    
    var items: [Sapiens] = []
    
    func append(_ item: Sapiens) {
        items.append(item)
    }
    
    
    
}







//: [Extensions](@next)
